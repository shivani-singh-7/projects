import { useState, useContext } from "react";
import { getRatedReview ,getBookById} from "../services"
import { BookContext } from "../context/BookContext";
import { StarComponent } from "./star-component";
import Details from "./details";
import {
    Route,
    Link,
    NavLink,
} from "react-router-dom";

function Reviews() {
    let options = ["All", "2+", "3+", "4+", "5"]
    const { state, dispatch } = useContext(BookContext);
    const [rating, setRating] = useState("1");
    const handleChange = (e: any) => {
        setRating(e.target.value);
    }
    const handleClick = () => {
        getRatedReview(dispatch, rating)
        console.log(rating);
    }


    return (
        <div>
            <select onChange={handleChange} >
                {/* <option value="1">All</option>
               <option  value="2">2+</option>
               <option value="3">3+</option> */}

                {options.map((value: any, index: number) => {
                    return (
                        <option key={index + 1} value={index + 1} >{value}</option>
                    )
                })}



            </select>
            <button type="submit" onClick={handleClick}>search</button>

            <div>
                {state.ratedReviews.map((review: any) => {
                    
                   return(
                   <div>
                        <NavLink to={"/details/" + review.bookId} style={{textDecoration:"none"}}>
                            <p style={{color:"black",fontSize:"large"}}>{review.name}</p>
                        <div className="alert alert-dark" role="alert"  onClick={() => {
                                    getBookById(dispatch, review.bookId);
                                }} ><h3>{review.title}</h3>
            "{review.review}"
            <br/><br/>
          
           Rating:<div className="stars"><span><StarComponent rating= {review.rating} outof={5} minof={1}></StarComponent></span></div>
            
          </div>
          </NavLink>
                    <Route path={"/details/" +review.bookId} component={Details} />
                       </div>
                   )
                  
                })}
            </div>


        </div>
    )
}

export default Reviews;