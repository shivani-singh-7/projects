"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* const mongoose=require("mongoose") */
var mongoose_1 = __importDefault(require("mongoose"));
var Schema = mongoose_1.default.Schema;
var ReviewSchema = new Schema({
    name: {
        type: String,
    },
    userId: {
        type: String,
    },
    bookId: {
        type: String,
    },
    review: {
        type: String,
    },
    rating: {
        type: String,
    },
    title: {
        type: String,
    },
});
var Reviews = mongoose_1.default.model('reviews', ReviewSchema);
module.exports = Reviews;
