/* const mongoose=require("mongoose") */
import mongoose from "mongoose"
const Schema=mongoose.Schema
 const ReviewSchema=new Schema({
    name:{
         type:String,
    },
    userId:{
        type:String,
    },
    bookId:{
        type:String,
    },
    review:{
        type:String,
    },
    rating:{
        type:String,
    },
    title:{
        type:String,
    },
}
 )
 const Reviews=mongoose.model('reviews',ReviewSchema)
 module.exports=Reviews